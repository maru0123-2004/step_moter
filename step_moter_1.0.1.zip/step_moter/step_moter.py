# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO #GPIO
import tkinter #GUI
from time import sleep #sleep

GPIO.setmode(GPIO.BCM)
GPIO.setup(14, GPIO.OUT)
GPIO.setup(15, GPIO.OUT)
GPIO.setup(23, GPIO.OUT)
GPIO.setup(24, GPIO.OUT)

a = 0
p_1 = 0
p_2 = 0

p1 = GPIO.PWM(14, 50)
p2 = GPIO.PWM(15, 50)
p3 = GPIO.PWM(23, 50)
p4 = GPIO.PWM(24, 50)

root = tkinter.Tk()
root.title("ステッピングモーター　設定")
root.geometry("400x300")

def b1_exit():
    GPIO.cleanup()
    exit()

def b2_set():
    p_1 = Scale1.get
    p_2 = Scale2.get

Scale1 =tkinter.Scale(label="1", width=50)
Scale1.pack(side="left")

Scale2 =tkinter.Scale(label="2", width=50)
Scale2.pack(side="right")

Button1 = tkinter.Button(text="終了/キャンセル", width=50, command=b1_exit)
Button1.pack(side="bottom")

Button2 = tkinter.Button(text="反映", width=50, command=b2_set)
Button2.pack(side="bottom")

root.mainloop()

try:
    while True:
        if a == 0:
            GPIO.output(14, GPIO.LOW)
            GPIO.output(15, GPIO.LOW)
            p3.start(p_2)
            GPIO.output(24, GPIO.LOW)
            a = 1
        elif a == 1:
            GPIO.output(14, GPIO.LOW)
            GPIO.output(15, GPIO.LOW)
            GPIO.output(23, GPIO.LOW)
            p4.start(p_2)
            a = 2
        elif a == 2:
            p1.start(p_1)
            GPIO.output(15, GPIO.LOW)
            GPIO.output(23, GPIO.LOW)
            GPIO.output(24, GPIO.LOW)
            a = 3
        elif a == 3:
            GPIO.output(14, GPIO.LOW)
            p2.start(p_1)
            GPIO.output(23, GPIO.LOW)
            GPIO.output(24, GPIO.LOW)
            a = 0

    

except KeyboardInterrupt:
    pass

GPIO.cleanup()
